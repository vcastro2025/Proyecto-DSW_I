package entidad;

public class Parametro {
	private Integer idParametro;
	private String nombre;
	private String valor;
	private String obs;

	public Integer getIdParametro() {
		return idParametro;
	}

	public void setIdParametro(Integer idParametro) {
		this.idParametro = idParametro;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getObs() {
		return obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

	@Override
	public String toString() {
		return "Parametro [idParametro=" + idParametro + ", nombre=" + nombre + ", valor=" + valor + ", obs=" + obs
				+ "]";
	}

}
