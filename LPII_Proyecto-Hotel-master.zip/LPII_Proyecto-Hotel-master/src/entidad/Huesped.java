package entidad;

public class Huesped {
	
}
