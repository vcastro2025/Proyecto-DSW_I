package dao;

import java.util.List;

import entidad.Equipamiento;

public class MySqlEquipamientoDAO implements EquipamientoDAO {

	@Override
	public List<Equipamiento> listaEquipamiento() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Equipamiento obtenerEquipamientoPorID(int idEquipamiento) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Equipamiento> consultaEquipamiento(String filtro) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insertaEquipamiento(Equipamiento equipamiento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int actualizaEquipamiento(Equipamiento equipamiento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int eliminaEquipamiento(int idEquipamiento) {
		// TODO Auto-generated method stub
		return 0;
	}



}
