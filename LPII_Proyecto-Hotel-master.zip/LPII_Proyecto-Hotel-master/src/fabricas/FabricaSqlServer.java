package fabricas;

import dao.ClienteDAO;
import dao.EquipamientoDAO;
import dao.HabitacionDAO;
import dao.HospedajeDAO;
import dao.PersonaDAO;
import dao.ProductoDAO;
import dao.TrabajadorDAO;
import dao.UsuarioDAO;

public class FabricaSqlServer extends Fabrica {

	@Override
	public ClienteDAO getClienteDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TrabajadorDAO getTrabajadorDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HospedajeDAO getHospedajeDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EquipamientoDAO getEquipamientoDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HabitacionDAO getHabitacionDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PersonaDAO getPersonaDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductoDAO getProductoDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UsuarioDAO getUsuarioDAO() {
		// TODO Auto-generated method stub
		return null;
	}

}
